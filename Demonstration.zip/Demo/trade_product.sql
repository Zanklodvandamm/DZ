-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: trade
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `ProductArticleNumber` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ProductName` text NOT NULL,
  `ProductDescription` text NOT NULL,
  `ProductPhoto` blob,
  `ProductCost` decimal(19,4) NOT NULL,
  `ProductDiscountAmount` tinyint DEFAULT NULL,
  `ProductTotalDiscountAmount` tinyint DEFAULT NULL,
  `ProductQuantityInStock` int NOT NULL,
  `ProductStatus` text,
  `CategoryID` int NOT NULL,
  `ManufacturerID` int NOT NULL,
  `SupplierID` int NOT NULL,
  PRIMARY KEY (`ProductArticleNumber`),
  KEY `CategoryID` (`CategoryID`),
  KEY `ManufacturerID` (`ManufacturerID`),
  KEY `SupplierID` (`SupplierID`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`),
  CONSTRAINT `product_ibfk_2` FOREIGN KEY (`ManufacturerID`) REFERENCES `manufacturer` (`ManufacturerID`),
  CONSTRAINT `product_ibfk_3` FOREIGN KEY (`SupplierID`) REFERENCES `supplier` (`SupplierID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('A346R4','Ручка шариковая автоматическая','Ручка шариковая автоматическая с синими чернилами, диаметр шарика 0,9 мм',_binary 'A346R4.jpg',35.0000,20,3,23,'В наличии',1,2,1),('A543T6','Ручка шариковая','Ручка шариковая Erich Krause, R-301 ORANGE 0.7 Stick, синий',_binary 'A543T6.jpg',13.0000,30,6,12,'В наличии',2,7,2),('B730E2','Ручка шариковая','Ручка шариковая одноразовая автоматическая Unimax Fab GP синяя (толщина линии 0.5 мм)',_binary 'B730E2.jpg',41.0000,10,3,45,'В наличии',1,3,1),('D419T7','Клей-карандаш','Клей-карандаш Erich Krause 15 гр.',_binary 'D419T7.png',61.0000,18,4,26,'В наличии',2,7,2),('F719R5','Папка-скоросшиватель','Папка-скоросшиватель, А4 Hatber/Хатбер 140/180мкм АССОРТИ, пластиковая с перфорацией прозрачный верх',_binary 'F719R5.jpg',18.0000,20,3,8,'В наличии',2,6,2),('G278R6','Ручка шариковая','Ручка шариковая FLEXOFFICE CANDEE 0,6 мм, синяя',_binary 'G278R6.png',15.0000,30,7,23,'В наличии',2,4,2),('H452A3','Тетрадь','Тетрадь, 24 листа, Зелёная обложка Hatber/Хатбер, офсет, клетка с полями',_binary 'H452A3.png',10.0000,8,3,25,'В наличии',4,6,2),('R259E6','Бумага офисная','Бумага офисная Svetocopy NEW A4 80г 500л',_binary 'R259E6.jpg',299.0000,25,4,32,'В наличии',3,5,2),('T564P5','Набор шариковых ручек одноразовых','Набор шариковых ручек одноразовых Attache Economy Spinner 10 цветов (толщина линии 0.5 мм)',_binary 'T564P5.jpg',50.0000,15,9,5,'В наличии',1,2,1),('А112Т4','Ручка шариковая','Ручка шариковая с синими чернилами,толщина стержня 7 мм',_binary 'А112Т4.jpg',12.0000,30,2,6,'В наличии',1,1,1);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-31 23:07:49
