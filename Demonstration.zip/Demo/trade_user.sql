-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: trade
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `UserID` int NOT NULL AUTO_INCREMENT,
  `UserSurname` varchar(100) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `UserPatronymic` varchar(100) NOT NULL,
  `UserLogin` text NOT NULL,
  `UserPassword` text NOT NULL,
  `UserRole` int NOT NULL,
  PRIMARY KEY (`UserID`),
  KEY `UserRole` (`UserRole`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`UserRole`) REFERENCES `role` (`RoleID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Никифоров','Всеволод','Иванович','loginDEjrm2018','Cpb+Im',1),(2,'Воронов','Донат','Никитевич','loginDEpxl2018','P6h4Jq',2),(3,'Игнатьева','Евгения','Валентиновна','loginDEwgk2018','&mfI9l',1),(4,'Буров','Федот','Егорович','loginDEpou2018','gX3f5Z',2),(5,'Семёнов','Иван','Семёнович','loginDEjwl2018','D4ZYHt',3),(6,'Денисов','Дамир','Филатович','loginDEabf2018','*Tasm+',1),(7,'Ершов','Максим','Геласьевич','loginDEwjm2018','k}DJKo',1),(8,'Копылов','Куприян','Пётрович','loginDEjvz2018','&|bGTy',3),(9,'Носов','Валерьян','Дмитрьевич','loginDEuyv2018','8hhrZ}',3),(10,'Силин','Игорь','Авдеевич','loginDExdm2018','DH68L9',2),(11,'Дроздова','Александра','Мартыновна','loginDEeiv2018','H*BxlS',3),(12,'Дроздов','Аркадий','Геласьевич','loginDEfuc2018','VuM+QT',1),(13,'Боброва','Варвара','Евсеевна','loginDEoot2018','usi{aT',3),(14,'Чернова','Агата','Данииловна','loginDElhk2018','Okk0jY',3),(15,'Лыткина','Ульяна','Станиславовна','loginDEazg2018','s3bb|V',1),(16,'Лаврентьев','Леонид','Игнатьевич','loginDEaba2018','s3bb|V',2),(17,'Кулаков','Юрий','Владленович','loginDEtco2018','tTKDJB',1),(18,'Соловьёв','Андрей','Александрович','loginDEsyq2018','2QbpBN',3),(19,'Корнилова','Марфа','Макаровна','loginDEpxi2018','+5X&hy',1),(20,'Белоусова','Любовь','Георгьевна','loginDEicr2018','3+|Sn{',1),(21,'Анисимов','Никита','Гордеевич','loginDEcui2018','Zi1Tth',3),(22,'Стрелкова','Фаина','Федосеевна','loginDEpxc2018','G+nFsv',1),(23,'Осипов','Евгений','Иванович','loginDEqrd2018','sApUbt',2),(24,'Владимирова','Иванна','Павловна','loginDEsso2018','s3bb|V',3),(25,'Кудрявцева','Жанна','Демьяновна','loginDErsy2018','{Aa6nS',3),(26,'Матвиенко','Яков','Брониславович','loginDEvpz2018','mS0UxK',3),(27,'Селезнёв','Егор','Артёмович','loginDEfog2018','glICay',1),(28,'Брагин','Куприян','Митрофанович','loginDEpii2018','Ob}RZB',1),(29,'Гордеев','Виктор','Эдуардович','loginDEhyk2018','*gN}Tc',2),(30,'Мартынов','Онисим','Брониславович','loginDEdxi2018','ywLUbA',3),(31,'Никонова','Евгения','Павловна','loginDEzro2018','B24s6o',3),(32,'Полякова','Анна','Денисовна','loginDEuxg2018','K8jui7',1),(33,'Макарова','Пелагея','Антониновна','loginDEllw2018','jNtNUr',1),(34,'Андреева','Анна','Вячеславовна','loginDEddg2018','gGGhvD',2),(35,'Кудрявцева','Кира','Ефимовна','loginDEpdz2018','s3bb|V',1),(36,'Шилова','Кира','Егоровна','loginDEyiw2018','cnj3QR',3),(37,'Ситников','Игорь','Борисович','loginDEqup2018','95AU|R',2),(38,'Русаков','Борис','Христофорович','loginDExil2018','w+++Ht',2),(39,'Капустина','Ульяна','Игоревна','loginDEkuv2018','Ade++|',3),(40,'Беляков','Семён','Германнович','loginDEmox2018','Je}9e7',3),(41,'Гурьев','Ириней','Игнатьевич','loginDEvug2018','lEa{Cn',1),(42,'Мишин','Христофор','Леонидович','loginDEzre2018','N*VX+G',1),(43,'Лазарева','Антонина','Христофоровна','loginDEbes2018','NaVtyH',3),(44,'Маркова','Ираида','Сергеевна','loginDEkfg2018','r1060q',1),(45,'Носкова','Пелагея','Валерьевна','loginDEyek2018','KY2BL4',1),(46,'Баранов','Станислав','Дмитрьевич','loginDEloq2018','NZV5WR',2),(47,'Ефремов','Демьян','Артёмович','loginDEjfb2018','TNT+}h',3),(48,'Константинов','Всеволод','Мэлсович','loginDEueq2018','GqAUZ6',3),(49,'Ситникова','Ираида','Андреевна','loginDEpqz2018','F0Bp7F',3),(50,'Матвеев','Кондрат','Иванович','loginDEovk2018','JyJM{A',2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-31 23:07:49
