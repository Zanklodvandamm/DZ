-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: trade
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `OrderID` int NOT NULL AUTO_INCREMENT,
  `OrderStatus` text NOT NULL,
  `OrderDeliveryDate` datetime NOT NULL,
  `OrderDate` datetime NOT NULL,
  `OrderArticleProductNumber` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `OrderCountProduct` int NOT NULL,
  `OrderPickupPoint` int NOT NULL,
  `OrderUserID` int NOT NULL,
  `OrderCodeGet` int NOT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `OrderUserID` (`OrderUserID`),
  KEY `OrderPickupPoint` (`OrderPickupPoint`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`OrderUserID`) REFERENCES `user` (`UserID`),
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`OrderPickupPoint`) REFERENCES `pickuppoint` (`PickUpPointID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'Новый','2024-05-20 22:00:00','2018-05-20 22:00:00','А112Т4',10,3,1,311),(2,'Завершен','2025-05-20 22:00:00','2019-05-20 22:00:00','A346R4',10,4,2,312),(3,'Новый','2026-05-20 22:00:00','2020-05-20 22:00:00','B730E2',10,5,3,313),(4,'Новый','2027-05-20 22:00:00','2021-05-20 22:00:00','H452A3',10,6,4,314),(5,'Завершен','2028-05-20 22:00:00','2022-05-20 22:00:00','F719R5',1,7,5,315),(6,'Новый','2029-05-20 22:00:00','2023-05-20 22:00:00','N459R6',2,10,6,316),(7,'Новый','2030-05-20 22:00:00','2024-05-20 22:00:00','J539R3',20,11,7,317),(8,'Новый','2031-05-20 22:00:00','2025-05-20 22:00:00','A567R4',5,20,8,318),(9,'Новый','2001-06-20 22:00:00','2026-05-20 22:00:00','K753R3',1,30,9,319),(10,'Новый','2002-06-20 22:00:00','2027-05-20 22:00:00','S425T6',5,33,10,320),(11,'Новый','2024-05-20 22:00:00','2018-05-20 22:00:00','R259E6',2,3,1,311),(12,'Завершен','2025-05-20 22:00:00','2019-05-20 22:00:00','T564P5',1,4,2,312),(13,'Новый','2026-05-20 22:00:00','2020-05-20 22:00:00','G278R6',10,5,3,313),(14,'Новый','2027-05-20 22:00:00','2021-05-20 22:00:00','A543T6',10,6,4,314),(15,'Завершен','2028-05-20 22:00:00','2022-05-20 22:00:00','D419T7',1,7,5,315),(16,'Новый','2029-05-20 22:00:00','2023-05-20 22:00:00','S276E6',15,10,6,316),(17,'Новый','2030-05-20 22:00:00','2024-05-20 22:00:00','Z539E3',1,11,7,317),(18,'Новый','2031-05-20 22:00:00','2025-05-20 22:00:00','K932R4',1,20,8,318),(19,'Новый','2001-06-20 22:00:00','2026-05-20 22:00:00','S563T6',1,30,9,319),(20,'Новый','2002-06-20 22:00:00','2027-05-20 22:00:00','A340R5',3,33,10,320);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-31 23:07:49
