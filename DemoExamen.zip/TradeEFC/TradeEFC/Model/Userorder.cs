﻿using System;
using System.Collections.Generic;

namespace TradeEFC.Model;

public partial class Userorder
{
    public int OrderId { get; set; }

    public DateOnly OrderDate { get; set; }

    public DateOnly OrderDeliveryDate { get; set; }

    public int OrderPickupPoint { get; set; }

    public string? OrderClientName { get; set; }

    public string OrderRecieveCode { get; set; } = null!;

    public string OrderStatus { get; set; } = null!;

    public virtual Pickuppoint OrderPickupPointNavigation { get; set; } = null!;

    public virtual ICollection<Orderproduct> Orderproducts { get; set; } = new List<Orderproduct>();
}
