﻿using System;
using System.Collections.Generic;

namespace TradeEFC.Model;

public partial class Pickuppoint
{
    public int PickupPointId { get; set; }

    public string? PickupPointCode { get; set; }

    public string? PickupPointCity { get; set; }

    public string? PickupPointStreet { get; set; }

    public string? PickupPointStreetNumber { get; set; }

    public virtual ICollection<Userorder> Userorders { get; set; } = new List<Userorder>();
}
