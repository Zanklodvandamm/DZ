﻿using System;
using System.Collections.Generic;

namespace TradeEFC.Model;

public partial class Product
{
    public string ProductArticleNumber { get; set; } = null!;

    public string ProductName { get; set; } = null!;

    public string ProductDescription { get; set; } = null!;

    public string ProductUnit { get; set; } = null!;

    public decimal ProductCost { get; set; }

    public sbyte? ProductMaxDiscountAmount { get; set; }

    public int ProductManufacturerId { get; set; }

    public int ProductDeliveryId { get; set; }

    public int ProductCategoryId { get; set; }

    public sbyte? ProductDiscountAmount { get; set; }

    public int ProductQuantityInStock { get; set; }

    public string? ProductPhoto { get; set; }

    public virtual ICollection<Orderproduct> Orderproducts { get; set; } = new List<Orderproduct>();

    public virtual Productcategory ProductCategory { get; set; } = null!;

    public virtual Delivery ProductDelivery { get; set; } = null!;

    public virtual Manufacturer ProductManufacturer { get; set; } = null!;
}
