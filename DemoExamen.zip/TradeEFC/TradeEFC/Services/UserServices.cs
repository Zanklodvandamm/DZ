﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradeEFC.Model.Data;
using TradeEFC.Model;

namespace TradeEFC.Services
{
    public class UserServices
    {
        public static List<User> GetUsers()
        {
            using (TradeContext db = new TradeContext())
            {
                var result = db.Users.ToList();
                return result;
            }
        }

    }
}
