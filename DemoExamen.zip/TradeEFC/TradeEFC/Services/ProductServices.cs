﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradeEFC.Model.Data;
using TradeEFC.Model;

namespace TradeEFC.Services
{
    public class ProductServices
    {
        public static List<Productcategory> GetCategory()
        {
            using (TradeContext db = new TradeContext())
            {
                var result = db.Productcategories.ToList();
                return result;
            }
        }

        public static List<Manufacturer> GetManufactures()
        {
            using (TradeContext db = new TradeContext())
            {
                var result = db.Manufacturers.ToList();
                return result;
            }
        }

        public static List<Delivery> GetDeliveries()
        {
            using (TradeContext db = new TradeContext())
            {
                var result = db.Deliveries.ToList();
                return result;
            }
        }

        public static List<Product> GetProducts()
        {
            using (TradeContext db = new TradeContext())
            {
                db.Productcategories.ToList();
                db.Manufacturers.ToList();
                db.Deliveries.ToList();
                var result = db.Products.ToList();
                return result;

            }
        }
    }
}
