﻿using DevExpress.Mvvm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TradeEFC.Model;

namespace TradeEFC.ViewModel
{
    public class LoginUser : BindableBase, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string _login;
        public string Login
        {
            get { return _login; }
            set
            {
                _login = value;
                NotifyPropertyChanged("Login");
            }
        }

        private string _password;
        public string Password
        {
            get { return _password; }
            set
            {
                _password = value;
                NotifyPropertyChanged("Password");
            }
        }
        public Model.RelayComands LoginCommand { get; set; }

        public LoginUser()
        {
            LoginCommand = new Model.RelayComands(LoginExecute);
        }

        private void LoginExecute(object obj)
        {
            List<User> listUsers = Services.UserServices.GetUsers();
            bool isAuthorized = false;
            foreach (User user in listUsers)
            {
                if (Login == user.UserLogin && Password == user.UserPassword)
                {
                    MessageBox.Show("Вы успешно авторизовались!");
                    isAuthorized = true;
                    break;
                }
            }

            if (isAuthorized)
            {
                // Экземпляр главного окна приложения
                MainWindow mainWindow = new MainWindow();

                // Показываем главное окно
                mainWindow.Show();

                // Закрываем окно авторизации
                var window = obj as Window;
                if (window != null)
                {
                    window.Close();
                }
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль!");
            }
        }

    }
}
