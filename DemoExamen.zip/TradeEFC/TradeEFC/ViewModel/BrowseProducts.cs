﻿using DevExpress.Mvvm;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TradeEFC.Model;
using TradeEFC.Services;
using TradeEFC.View;

namespace TradeEFC.ViewModel
{
    public class BrowseProduct : BindableBase, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        private List<Product> products = Services.ProductServices.GetProducts();
        public List<Product> Products
        {
            get { return products; }
            set
            {
                products = value;
                NotifyPropertyChanged("Products");
            }
        }

        public static Product? SelectedProduct { get; set; }

        public List<string> Sorts { get; set; } = new() { "По умолчанию", "По возрастанию", "По убыванию" };

        public List<string> Filters { get; set; } = new() { "Все диапазоны", "0-5%", "5-9%", "9% и более" };

        public string SelectedSort
        {
            get { return GetValue<string>(); }
            set { SetValue(value, changedCallback: UpdateProduct); }
        }
        public string SelectedFilter
        {
            get { return GetValue<string>(); }
            set { SetValue(value, changedCallback: UpdateProduct); }
        }
        public string Search
        {
            get { return GetValue<string>(); }
            set { SetValue(value, changedCallback: UpdateProduct); }
        }

        private void UpdateProduct()
        {
            var currentProduct = Services.ProductServices.GetProducts();

            if (!string.IsNullOrEmpty(SelectedFilter))
            {
                switch (SelectedFilter)
                {
                    case "0-5%":
                        currentProduct = currentProduct.Where(p => (float)p.ProductDiscountAmount is >= 0 and < 5).ToList();
                        break;
                    case "5-9%":
                        currentProduct = currentProduct.Where(p => (float)p.ProductDiscountAmount is >= 5 and < 9).ToList();
                        break;
                    case "9% и более":
                        currentProduct = currentProduct.Where(p => (float)p.ProductDiscountAmount is >= 9).ToList();
                        break;
                }
            }

            if (!string.IsNullOrEmpty(Search))
                currentProduct = currentProduct.Where(p => p.ProductName.ToLower().Contains(Search.ToLower())).ToList();

            if (!string.IsNullOrEmpty(SelectedSort))
            {
                switch (SelectedSort)
                {
                    case "По возрастанию":
                        currentProduct = currentProduct.OrderBy(p => p.ProductCost).ToList();
                        break;
                    case "По убыванию":
                        currentProduct = currentProduct.OrderByDescending(p => p.ProductCost).ToList();
                        break;
                }
            }

            Products = currentProduct;
        }
        private RelayComands openAddNewProductWnd;

        private RelayComands openRemoveProductWnd
        {
            get
            {
                return openAddNewProductWnd ?? new RelayComands(obj =>
                {
                    OpenAddNewProductMethod();
                }
                    );
            }
        }

        private static void OpenAddNewProductMethod()
        {
            View.AddNewProduct addNewProduct = new View.AddNewProduct();
            addNewProduct.Owner = Application.Current.MainWindow;
            addNewProduct.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            addNewProduct.ShowDialog();
        }
    }
}
